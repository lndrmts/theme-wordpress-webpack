import './sass/styles.scss';

import bar from './javascripts/custom';

import './images/webpack.png';

bar();
