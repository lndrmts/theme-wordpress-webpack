export default function bar() {
  console.log('Ready for use!');
}
